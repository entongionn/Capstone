"""
Script di scraping della lista dei manga su MangaWorld

Questo script è progettato per raccogliere l'elenco completo dei manga presenti su MangaWorld, inclusi i loro titoli e URL. Utilizza Selenium per navigare tra le pagine dell'archivio del sito e salvare i dati in un file CSV. Questo file CSV sarà poi utilizzato come input per ulteriori fasi di arricchimento dei metadati, come l'estrazione di visualizzazioni, autori e altri dettagli.

Funzionalità principali:
- Navigazione automatica tra le pagine dell'archivio di MangaWorld
- Estrazione di titoli e URL dei manga

Note tecniche:
- Lo script utilizza la modalità headless per migliorare le prestazioni.
- Viene utilizzata la libreria `unidecode` per rimuovere caratteri speciali dai titoli.
- Gestisce l'interruzione del ciclo in caso di pagine vuote per evitare errori.

"""

from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
import pandas as pd
from unidecode import unidecode
import time

# Impostazioni del browser (modalità headless)
chrome_options = Options()
chrome_options.add_argument("--headless")

# Percorso al ChromeDriver
chrome_driver_path = 'C:\\Users\\giovi\\Desktop\\Visual Studio Code\\chromedriver-win64\\chromedriver.exe'
service = Service(chrome_driver_path)
driver = webdriver.Chrome(service=service, options=chrome_options)

# Funzione per normalizzare i titoli
def normalize(text):
    return unidecode(text).lower().strip()

# Impostazioni di scraping
base_url = "https://www.mangaworld.nz/archive?page="
max_pages = 183  # Numero di pagine da scorrere (può variare nel tempo)

# Lista per salvare i risultati
manga_titles = []

# Loop su tutte le pagine dell’archivio
for page in range(1, max_pages + 1):
    url = f"{base_url}{page}"
    driver.get(url)
    time.sleep(1)  # attesa per il caricamento della pagina

    manga_elements = driver.find_elements(By.CSS_SELECTOR, "a.manga-title")

    if not manga_elements:
        print(f"Nessun manga trovato nella pagina {page}. Interrotto il ciclo.")
        break

    print(f"Pagina {page}: trovati {len(manga_elements)} manga")

    for el in manga_elements:
        title = el.text.strip()
        link = el.get_attribute("href")
        manga_titles.append({"title": title, "url": link})

# Chiusura del browser
driver.quit()

# Creazione DataFrame e salvataggio
manga_df = pd.DataFrame(manga_titles)

if "title" in manga_df.columns:
    manga_df["title_normalized"] = manga_df["title"].apply(normalize)
else:
    print("La colonna 'title' non è presente.")

print(manga_df.head())
manga_df.to_csv("mangaworld_metadata_scraped_parziale.csv", index=False)
print("File salvato come 'mangaworld_metadata_scraped_parziale.csv'")
