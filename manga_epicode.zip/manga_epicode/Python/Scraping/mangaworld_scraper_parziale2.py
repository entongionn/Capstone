"""
Script di estrazione metadati da MangaWorld

Questo script è stato sviluppato per automatizzare l'estrazione dei metadati dai dettagli delle pagine manga su MangaWorld. Utilizza Selenium per accedere alle pagine dei singoli manga e raccogliere informazioni che non sono direttamente disponibili nel CSV iniziale. I metadati estratti includono:

- Titolo principale
- URL della pagina del manga
- Visualizzazioni
- Titoli alternativi
- Autore
- Artista
- Tipo (es. Manga, Manhwa, Manhua)
- Stato (es. In corso, Completato)
- Anno di uscita

Questi dati sono essenziali per l'analisi del mercato dei manga in Italia e per il matching con altre fonti come MangaDex e MyAnimeList. Il risultato è salvato in un file CSV che può essere utilizzato per analisi successive o per l'integrazione con altri dataset.

Note tecniche:
- Lo script è ottimizzato per esecuzioni headless per migliorare le prestazioni.
- Sono gestiti i timeout e gli errori durante l'estrazione per evitare interruzioni improvvise.

"""

from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
import pandas as pd
import time

# Impostazioni del browser (headless)
chrome_options = Options()
chrome_options.add_argument("--headless")

# Percorso al ChromeDriver
chrome_driver_path = 'C:\\Users\\giovi\\Desktop\\Visual Studio Code\\chromedriver-win64\\chromedriver.exe'
service = Service(chrome_driver_path)
driver = webdriver.Chrome(service=service, options=chrome_options)

# Carica il CSV con titolo e URL
df = pd.read_csv("mangaworld_metadata_scraped_parziale.csv")

# Funzione per estrarre le informazioni dalla pagina del manga
def estrai_metadati(link):
    try:
        driver.get(link)
        time.sleep(2)
        spans = driver.find_elements(By.TAG_NAME, "span")
        titles_alternativi = None
        autore = None
        artista = None
        tipo = None
        stato = None
        anno_uscita = None
        visualizzazioni = None

        # Estrai le visualizzazioni
        for s in spans:
            text = s.text.replace(",", "").strip()
            if text.isdigit() and int(text) > 100:  # Ignora numeri piccoli
                visualizzazioni = int(text)
                break
        
        # Estrai altri metadati
        elements = driver.find_elements(By.CLASS_NAME, "col-12") + driver.find_elements(By.CLASS_NAME, "col-12.col-md-6")
        for el in elements:
            label = el.find_element(By.TAG_NAME, "span").text.strip()
            value = el.text.replace(label, "").strip()
            if label == "Titoli alternativi: ":
                titles_alternativi = value.split(", ")
            elif label == "Autore: ":
                autore = value
            elif label == "Artista: ":
                artista = value
            elif label == "Tipo: ":
                tipo = value
            elif label == "Stato: ":
                stato = value
            elif label == "Anno di uscita: ":
                anno_uscita = value
        
        return {
            "views": visualizzazioni,
            "alt_titles": titles_alternativi,
            "author": autore,
            "artist": artista,
            "type": tipo,
            "status": stato,
            "year": anno_uscita
        }
    except Exception as e:
        print(f"Errore durante l'estrazione da {link}: {e}")
        return None

# Estrai metadati per ogni manga
metadata_list = []
for i, row in df.iterrows():
    url = row["url"]
    titolo = row["title"]
    metadati = estrai_metadati(url)
    if metadati:
        metadati["title"] = titolo
        metadati["url"] = url
        metadata_list.append(metadati)
    print(f"{i+1}/{len(df)} - {titolo} - {metadati}")

# Crea un DataFrame e salva il file
metadata_df = pd.DataFrame(metadata_list)
metadata_df.to_csv("mangaworld_dataset.csv", index=False)
print("File aggiornato salvato come 'mangaworld_dataset.csv'")

# Chiudi il browser
driver.quit()
