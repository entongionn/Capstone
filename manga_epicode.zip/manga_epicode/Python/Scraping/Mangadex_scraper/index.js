// MangaDex Full Metadata Extractor for Matching (API V5 Direct)

import fs from 'fs';
import fetch from 'node-fetch';

// Funzione per normalizzare i campi di testo
function cleanText(text) {
    if (!text) return "";
    return text.replace(/\s+/g, ' ').replace(/,/g, ';').replace(/"/g, "'").trim();
}

// Estrazione dei metadati e statistiche
async function extractMetadata(mangaId) {
    try {
        // Chiamata API diretta per ottenere i metadati del manga
        const metadataResponse = await fetch(`https://api.mangadex.org/manga/${mangaId}?includes[]=author&includes[]=artist&includes[]=cover_art&includes[]=tag`);
        const metadataData = await metadataResponse.json();
        const attributes = metadataData.data.attributes;
        const relationships = metadataData.data.relationships;

        // Estrazione delle informazioni principali
        const title = cleanText(attributes.title.en || Object.values(attributes.title)[0] || "");
        const alt_titles = attributes.altTitles.map(t => cleanText(Object.values(t)[0])).join(" | ");
        const description = cleanText(attributes.description.en || "");
        const year = attributes.year || "";
        const status = attributes.status || "";
        const demographic = attributes.publicationDemographic || "";
        const content_rating = attributes.contentRating || "";
        const updated_at = attributes.updatedAt || "";

        // Estrazione di autore e artista
        const author = cleanText(relationships.find(r => r.type === 'author')?.attributes?.name || "");
        const artist = cleanText(relationships.find(r => r.type === 'artist')?.attributes?.name || "");

        // Estrazione dei generi
        const genres = relationships.filter(r => r.type === 'tag').map(tag => cleanText(tag.attributes.name.en)).join(" | ");

        // Chiamata API per ottenere le statistiche del manga
        const statsResponse = await fetch(`https://api.mangadex.org/statistics/manga/${mangaId}`);
        const statsData = await statsResponse.json();
        const stats = statsData.statistics[mangaId] || {};
        const follows = stats.follows || 0;
        const rating = stats.rating?.average || 0;
        const rating_count = stats.rating?.bayesian || 0;
        const comments = stats.comments || 0;

        // Creazione dell'oggetto metadati
        const metadata = {
            manga_id: mangaId,
            title_api: title,
            alt_titles: alt_titles,
            author: author,
            artist: artist,
            genres: genres,
            demographic: demographic,
            status: status,
            year: year,
            description: description,
            content_rating: content_rating,
            last_updated: updated_at,
            follows: follows,
            rating: rating,
            rating_count: rating_count,
            comments: comments
        };

        return metadata;

    } catch (error) {
        console.error(`Errore durante l'estrazione dei metadati per ${mangaId}:`, error);
        return null;
    }
}

// Estrazione di tutti i manga
async function main() {
    try {
        const mangaList = JSON.parse(fs.readFileSync("mangadex_list.json", "utf8"));
        const metadataList = [];

        for (const mangaId of mangaList) {
            console.log(`Estrazione di ${mangaId}...`);
            const metadata = await extractMetadata(mangaId);
            if (metadata) {
                metadataList.push(metadata);
            }
        }

        // Salva i risultati in CSV
        const headers = Object.keys(metadataList[0]).join(",");
        const rows = metadataList.map(m => Object.values(m).map(v => `"${v}"`).join(",")).join("\n");
        const csvContent = `${headers}\n${rows}`;
        fs.writeFileSync("mangadex_full_metadata.csv", csvContent);
        console.log("Dati salvati in 'mangadex_full_metadata.csv'.");

    } catch (error) {
        console.error("Errore durante l'estrazione dei dati:", error);
    }
}

// Avvia l'estrazione
main();
